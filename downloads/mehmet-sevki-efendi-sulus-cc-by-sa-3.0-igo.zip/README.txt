Meşk Aynası — Mehmet Şevki Efendi Sülüs Referansları

Eser:
Album of Alphabetical Exercises (Murakkabat) by Mehmed Shevki

Hattat:
Mehmet Şevki Efendi (1829–1887)

Koleksiyon:
Khalili Collections, MSS 239

Kaynak görsel:
https://commons.wikimedia.org/wiki/File:Khalili_Collection_Islamic_Art_mss_0239.15.jpg

Lisans:
Creative Commons Attribution-ShareAlike 3.0 IGO
https://creativecommons.org/licenses/by-sa/3.0/igo/

Atıf:
Khalili Collections / CC BY-SA 3.0 IGO

Değişiklikler:
Meşk Aynası için harflere göre kırpılmış, siyah-beyaza dönüştürülmüş ve
temizlenmiştir.

Bu paketteki türetilmiş PNG dosyaları CC BY-SA 3.0 IGO altında sunulur.
Kaynak kurumun Meşk Aynası'nı desteklediği veya onayladığı ima edilmez.
